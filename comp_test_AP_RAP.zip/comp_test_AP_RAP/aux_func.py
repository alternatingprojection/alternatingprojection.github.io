# %% Imports

from random import choice
import numpy as np
from scipy import linalg
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

import mne
from mne.cov import regularize
from mne.beamformer import alternating_projections, rap_music

# %% Simulate

def gen_signals_correlated_cos(corr,Q,T,min_t,max_t):
    Cov     = np.ones((Q,Q))*corr + np.diag(np.ones(Q))*(1-corr)
    # random frequencies between low Hz to high Hz
    freq    = np.random.randint(low=10,high=120,size=[Q,1])+1
    phases  = 2*np.pi*np.random.rand(Q,1)
    t       = np.linspace(min_t,max_t,T)
    # the basic signals
    Signals = np.sqrt(2)*np.cos(2*np.pi*freq*t+phases)
    if corr < 1:
        # Cholesky Decomposition
        A = np.linalg.cholesky(Cov)
        Y = np.dot(A,Signals)
    else:
        Y = np.tile(Signals[0,],[Q,1])
    return Y


def simu_data(evoked, forward, noise_cov, times, corr, target_snr, nave=100):
    """Simulate an evoked dataset with 2 sources.

    One source is put in each hemisphere.
    """
    # Generate the two dipoles data
    Q = 2
    T = len(evoked.times)
    min_t = np.min(evoked.times)
    max_t = np.max(evoked.times)

    while True:
        Y = gen_signals_correlated_cos(corr, Q, T, min_t, max_t)
        corr_test = np.abs((Y[0]/np.linalg.norm(Y[0]))@(Y[1].T/np.linalg.norm(Y[1])))
        if corr-0.02 < corr_test < corr+0.02:
            break

    data = np.array([Y[0], Y[1]])

    sig_corr = corr_test

    src = forward['src']

    rndi = np.random.randint(len(src[0]['vertno']))
    lh_vertno = src[0]['vertno'][[rndi]]

    rndi = np.random.randint(len(src[1]['vertno']))
    rh_vertno = src[1]['vertno'][[rndi]]

    vertices = [lh_vertno, rh_vertno]
    tmin, tstep = times.min(), 1 / evoked.info['sfreq']
    stc = mne.SourceEstimate(data, vertices=vertices, tmin=tmin, tstep=tstep)
    sim_evoked = mne.forward.apply_forward(forward, stc, evoked.info)

    noise = mne.simulation.evoked._simulate_noise_evoked(evoked, noise_cov, iir_filter=None, random_state=None)
    noise = noise.data / np.sqrt(nave)
    p = (target_snr/20) + np.log10(np.linalg.norm(noise)/np.linalg.norm(sim_evoked.data))
    sim_evoked.data *= 10**p
    SNR = 20*np.log10(np.linalg.norm(sim_evoked.data)/np.linalg.norm(noise))

    sim_evoked.data += noise

    return sim_evoked, stc, SNR, sig_corr


def add_results(df, evoked, dip, res, pos, ori, SNR, sig_corr, Algo):
    
    est_pos = np.concatenate([[dip[0].pos[0]],[dip[1].pos[0]]],axis=0)
    est_ori = np.concatenate([[dip[0].ori[0]],[dip[1].ori[0]]],axis=0)

    dip_dis = np.sqrt(np.sum((pos[1]-pos[0])**2))
    ##### assigning positional error
    dis1 = np.sqrt(np.sum((est_pos-pos[0])**2,axis=1))
    dis2 = np.sqrt(np.sum((est_pos-pos[1])**2,axis=1))
    am_dis1 = np.argmin(dis1)
    am_dis2 = np.argmin(dis2)
    if am_dis1==am_dis2:
        select_dip = np.argmin([dis1[am_dis1],dis2[am_dis2]])
        if bool(select_dip):
            pos_err_2 = dis2[am_dis2]
            assign2 = am_dis2
            pos_err_1 = dis1[int(not bool(am_dis2))]
            assign1 = int(not bool(am_dis2))
        else:
            pos_err_1 = dis1[am_dis1]
            assign1 = am_dis1
            pos_err_2 = dis2[int(not bool(am_dis1))]
            assign2 = int(not bool(am_dis1))
    else:
        pos_err_1 = dis1[am_dis1]
        assign1 = am_dis1
        pos_err_2 = dis2[am_dis2]
        assign2 = am_dis2

    #### orientation correlation
    ori_corr_1 = np.dot(est_ori[assign1,np.newaxis],ori[0,np.newaxis].T)[0][0]
    ori_corr_2 = np.dot(est_ori[assign2,np.newaxis],ori[1,np.newaxis].T)[0][0]

    #### rel_tol
    picks_grad = mne.pick_types(res.info, meg='grad')
    picks_mag = mne.pick_types(res.info, meg='mag')
    rel_tol_mag = linalg.norm(res.data[picks_mag], ord='fro')/linalg.norm(evoked.data[picks_mag], ord='fro')
    rel_tol_grad = linalg.norm(res.data[picks_grad], ord='fro')/linalg.norm(evoked.data[picks_grad], ord='fro')

    new_samp = pd.DataFrame(
        {
            'Algo':Algo,
            'SNR':SNR,
            'Sig_corr':sig_corr,
            'Simulated_dis':dip_dis,
            'Pos_err_1':pos_err_1,
            'Pos_err_2':pos_err_2,
            'Ori_corr_1':ori_corr_1,
            'Ori_corr_2':ori_corr_2,
            'rel_tol_mag':rel_tol_mag,
            'rel_tol_grad':rel_tol_grad
        },
        index=[0]
    )
    df = pd.concat([df,new_samp],ignore_index=True)

    return df


def get_data(fname_ave,fname_cov,ch_decim=1):
    """Read in data used in tests."""
    # Read evoked
    condition = choice(['Left Auditory',
                        'Right Auditory',
                        'Left visual',
                        'Right visual'])
    evoked = mne.read_evokeds(fname_ave, condition=condition,
                              baseline=(None, 0))
    evoked.crop(tmin=0.05, tmax=0.15)
    picks = mne.pick_types(evoked.info, meg=True, eeg=False)
    picks = picks[::ch_decim]
    evoked.pick_channels([evoked.ch_names[pick] for pick in picks])
    evoked.info.normalize_proj()

    # Read noise_cov
    noise_cov = mne.read_cov(fname_cov)
    noise_cov['projs'] = []
    noise_cov = regularize(noise_cov, evoked.info, rank='full', proj=False)

    return evoked, noise_cov


def run_simulation(
    fwd_fixed, noise_cov, evoked,
    sig_corr_seeds = [0.5,0.7,0.85,0.9,0.95,1], snr_seeds = [-15,-10,-5,0,5,10,15],
    fwd_free = None, samples = 500, verbose = True):

    src = fwd_fixed['src']
    fwd = fwd_free if fwd_free!=None else fwd_fixed

    test_data= pd.DataFrame(
        columns=[
            'Algo', 'SNR', 'Sig_corr', 'Simulated_dis',
            'Pos_err_1', 'Pos_err_2', 'Ori_corr_1',
            'Ori_corr_2', 'rel_tol_mag', 'rel_tol_grad']
    )
    for corr in sig_corr_seeds:
        for target_snr in snr_seeds:
            for samp in range(samples):
                sim_evoked, stc, SNR, sig_corr = simu_data(evoked, fwd_fixed, noise_cov, evoked.times, corr, target_snr)

                ind1 = [np.where(src[0]['vertno'] == stc.vertices[0])[0]][0][0]
                ind2 = [np.where(src[1]['vertno'] == stc.vertices[1])[0] + len(src[0]['vertno'])][0][0]

                pos1 = fwd_fixed['source_rr'][np.where(src[0]['vertno'] == stc.vertices[0])]
                pos2 = fwd_fixed['source_rr'][np.where(src[1]['vertno'] == stc.vertices[1])[0] + len(src[0]['vertno'])]
                pos = np.concatenate([pos1,pos2],axis=0)

                ori1 = fwd_fixed['source_nn'][ind1]
                ori2 = fwd_fixed['source_nn'][ind2]
                ori = np.concatenate([[ori1],[ori2]],axis=0)
                
                dip_ap, res_ap, _, _ = alternating_projections(
                    sim_evoked, fwd, 2, noise_cov, force_no_rep=True, verbose=verbose)
                test_data = add_results(
                    test_data, sim_evoked, dip_ap, res_ap, pos, ori, SNR, sig_corr, 'AP')

                dip_rap, res_rap = rap_music(
                    sim_evoked, fwd, noise_cov, n_dipoles=2, return_residual=True, force_no_rep=True, verbose=verbose)          
                test_data = add_results(
                    test_data, sim_evoked, dip_rap, res_rap, pos, ori, SNR, sig_corr, 'RAP')

                print(
                    f"""
                    corr={corr}, snr={target_snr}, sample={samp+1}
                    """
                )

    return test_data

# %% Prepering data set

def costum_cluster(df,label,bound,seed_list):
    intervals = [pd.Interval(x-bound,x+bound) for x in seed_list]
    assign_series = df[label].apply(lambda x: [x in interval for interval in intervals]) 
    assign_series = assign_series[[np.any(assign_series[x]) for x in range(assign_series.size)]]
    assign_series = assign_series.apply(lambda x: seed_list[np.argmax(x)])
    filter_df = df.loc[assign_series.index]
    filter_df[f"{label}_bin"] = assign_series
    return filter_df


def prep_data(test_data, sig_corr_seeds, snr_seeds):
    tmp_corr_data = costum_cluster(test_data, "Sig_corr", 0.03, sig_corr_seeds)
    tmp_corr_data.reset_index(inplace = True)
    tmp_corr_data = costum_cluster(tmp_corr_data, "SNR", 0.2, snr_seeds)
    tmp_corr_data.reset_index(inplace = True)
    tmp_corr_data["Ori_corr_1"] = tmp_corr_data["Ori_corr_1"].apply(lambda x: np.abs(x))
    tmp_corr_data["Ori_corr_2"] = tmp_corr_data["Ori_corr_2"].apply(lambda x: np.abs(x))
    tmp_corr_data["max_distance"] = tmp_corr_data[['Pos_err_1', 'Pos_err_2']].max(axis=1)
    tmp_corr_data["avg_distance"] = tmp_corr_data[['Pos_err_1', 'Pos_err_2']].mean(axis=1)
    tmp_corr_data["min_distance"] = tmp_corr_data[['Pos_err_1', 'Pos_err_2']].min(axis=1)
    tmp_corr_data["avg_ori_corr"] = tmp_corr_data[['Ori_corr_1', 'Ori_corr_2']].mean(axis=1)
    tmp_corr_data["avg_rel_tol"] = tmp_corr_data[['rel_tol_mag', 'rel_tol_grad']].mean(axis=1)
    tmp_corr_data.drop(columns=['level_0', 'index'],inplace=True)

    ap_heatmap_prep = pd.pivot_table(
        tmp_corr_data[tmp_corr_data["Algo"] == "AP"],
        values=["avg_ori_corr", "avg_distance", "avg_rel_tol"],
        index="SNR_bin",columns="Sig_corr_bin")
    rap_heatmap_prep = pd.pivot_table(
        tmp_corr_data[tmp_corr_data["Algo"] == "RAP"],
        values=["avg_ori_corr", "avg_distance", "avg_rel_tol"],
        index="SNR_bin", columns="Sig_corr_bin")
                                    

    return tmp_corr_data, ap_heatmap_prep, rap_heatmap_prep

# %% Plotting 

def plot_line_by_attr_free_ori(tmp_corr_data, attr1, attr2, seed, additional_info):

    corr_data = tmp_corr_data[tmp_corr_data[attr1]==seed]
    corr_data.reset_index(inplace=True)
    fig, ax = plt.subplots(3,2,sharex=True)
    fig.suptitle(f"{additional_info['set_attr']} = {corr_data[attr1][0]}, {additional_info['ori']}", ha = 'right')

    sns.lineplot(
        data = corr_data, x=attr2, y = "avg_distance", hue = "Algo", ax = ax[0][0])
    ax[0][0].set(ylabel = 'Avg distance [m]')
    handles, labels = ax[0][0].get_legend_handles_labels()
    ax[0][0].legend().remove()
    ax[0][0].grid()

    sns.lineplot(
        data = corr_data, x = attr2, y = "max_distance", hue = "Algo", ax = ax[0][1], legend = False)
    ax[0][1].set(ylabel='Max distance [m]')
    ax[0][1].grid()

    sns.lineplot(
        data = corr_data, x = attr2, y = "min_distance", hue = "Algo", ax = ax[1][0], legend = False)
    ax[1][0].set(ylabel = 'Min distance [m]')
    ax[1][0].grid()

    sns.lineplot(
        data = corr_data, x = attr2, y = "avg_ori_corr", hue = "Algo", ax = ax[1][1], legend = False)
    ax[1][1].set(ylabel = 'Orient. Corr.')
    ax[1][1].grid()

    sns.lineplot(
        data = corr_data, x = attr2, y = "rel_tol_grad", hue = "Algo", ax = ax[2][0], legend = False)
    ax[2][0].set(ylabel = 'Rel. Tol. Grad.', xlabel = additional_info['xlabel'])
    ax[2][0].grid()

    sns.lineplot(
        data = corr_data, x = attr2, y = "rel_tol_mag", hue="Algo", ax = ax[2][1], legend = False)
    ax[2][1].set(ylabel = 'Rel. Tol. Mag.', xlabel = additional_info['xlabel'])
    ax[2][1].grid()

    fig.legend(
        handles, labels, title = "Method", loc = 'upper right', ncol = 2,
        frameon = False)

    plt.tight_layout()
    return fig, ax


def plot_heatmap_diff_free_ori(ap_heatmap_prep, rap_heatmap_prep):
    select_ind = range(2,5) #aiming for SNR = [-5,0,5]
    ap_heatmap_prep = ap_heatmap_prep.iloc[select_ind]
    rap_heatmap_prep = rap_heatmap_prep.iloc[select_ind]
    fig, ax = plt.subplots(3,1,sharex=True,sharey=True)
    fig.suptitle('AP - RAP', ha = 'right')

    a = ap_heatmap_prep["avg_distance"]-rap_heatmap_prep["avg_distance"]
    sns.heatmap(data=a, annot=True, ax=ax[0], cmap='vlag',
                cbar_kws={'ticks': [-0.05,-0.025,0.0,0.025,0.05]}, vmin=-0.05, vmax=0.05,
                fmt='.3f')
    ax[0].set(title='Average distance [m]', xlabel=None, ylabel="SNR")

    a = ap_heatmap_prep["avg_ori_corr"]-rap_heatmap_prep["avg_ori_corr"]
    sns.heatmap(data=a, annot=True, ax=ax[1], cmap='vlag',
                cbar_kws={'ticks': [-0.3,-0.15,0.0,0.15,0.3]}, vmin=-0.3, vmax=0.3,
                fmt='.3f')
    ax[1].set(title='Orientation correlation', xlabel=None, ylabel="SNR")

    a = ap_heatmap_prep["avg_rel_tol"]-rap_heatmap_prep["avg_rel_tol"]
    sns.heatmap(data=a, annot=True, ax=ax[2], cmap='vlag',
                cbar_kws={'ticks': [-0.3,-0.15,0.0,0.15,0.3]}, vmin=-0.3, vmax=0.3,
                fmt='.3f')
    ax[2].set(title='Relative Tolerance', xlabel='Inter-source correlation', ylabel="SNR")

    plt.tight_layout()
    return fig, ax


def plot_heatmaps_free_ori(ap_heatmap_prep, rap_heatmap_prep):
    select_ind = range(2,5) #aiming for SNR = [-5,0,5]
    ap_heatmap_prep = ap_heatmap_prep.iloc[select_ind]
    rap_heatmap_prep = rap_heatmap_prep.iloc[select_ind]
    fig, ax = plt.subplots(3,2,sharex=True,sharey=True)

    sns.heatmap(data=ap_heatmap_prep["avg_distance"],annot=True,ax=ax[0][0])
    ax[0][0].set(title='AP avg dist[m]', xlabel=None, ylabel="SNR")

    sns.heatmap(data=rap_heatmap_prep["avg_distance"],annot=True,ax=ax[0][1])
    ax[0][1].set(title='RAP avg dist[m]', xlabel=None, ylabel=None)

    sns.heatmap(data=ap_heatmap_prep["avg_ori_corr"],annot=True,ax=ax[1][0])
    ax[1][0].set(title='AP orientation correlation', xlabel=None, ylabel="SNR")

    sns.heatmap(data=rap_heatmap_prep["avg_ori_corr"],annot=True,ax=ax[1][1])
    ax[1][1].set(title='RAP orientation correlation', xlabel=None, ylabel=None)

    sns.heatmap(data=ap_heatmap_prep["avg_rel_tol"],annot=True,ax=ax[2][0])
    ax[2][0].set(title='AP rel_tol', xlabel='Inter-source correlation', ylabel="SNR")

    sns.heatmap(data=rap_heatmap_prep["avg_rel_tol"],annot=True,ax=ax[2][1])
    ax[2][1].set(title='RAP rel_tol', xlabel='Inter-source correlation', ylabel="SNR")

    plt.tight_layout()
    return fig, ax


def plot_line_by_attr_fixed_ori(tmp_corr_data,attr1,attr2,seed, additional_info):

    corr_data = tmp_corr_data[tmp_corr_data[attr1]==seed]
    corr_data.reset_index(inplace=True)
    fig, ax = plt.subplots(2,2,sharex=True)
    fig.suptitle(f"{additional_info['set_attr']} = {corr_data[attr1][0]}, {additional_info['ori']}", ha='right')

    sns.lineplot(
        data = corr_data, x=attr2, y = "avg_distance", hue = "Algo", ax = ax[0][0])
    ax[0][0].set(ylabel = 'Avg distance [m]')
    handles, labels = ax[0][0].get_legend_handles_labels()
    ax[0][0].legend().remove()
    ax[0][0].grid()

    sns.lineplot(
        data = corr_data, x = attr2, y = "max_distance", hue = "Algo", ax = ax[0][1], legend = False)
    ax[0][1].set(ylabel='Max distance [m]')
    ax[0][1].grid()

    sns.lineplot(
        data = corr_data, x = attr2, y = "min_distance", hue = "Algo", ax = ax[1][0], legend = False)
    ax[1][0].set(ylabel = 'Min distance [m]', xlabel = additional_info['xlabel'])
    ax[1][0].grid()

    sns.lineplot(
        data = corr_data, x = attr2, y = "avg_rel_tol", hue = "Algo", ax = ax[1][1], legend = False)
    ax[1][1].set(ylabel = 'Average relative tolerance', xlabel = additional_info['xlabel'])
    ax[1][1].grid()

    fig.legend(
        handles, labels, title = "Method", loc = 'upper right', ncol = 2,
        frameon = False)

    plt.tight_layout()
    return fig, ax


def plot_heatmap_diff_fixed_ori(ap_heatmap_prep, rap_heatmap_prep):
    select_ind = range(2,5) #aiming for SNR = [-5,0,5] 
    ap_heatmap_prep = ap_heatmap_prep.iloc[select_ind]
    rap_heatmap_prep = rap_heatmap_prep.iloc[select_ind]
    fig, ax = plt.subplots(2,1,sharex=True,sharey=True)
    fig.suptitle('AP - RAP')

    a = ap_heatmap_prep["avg_distance"]-rap_heatmap_prep["avg_distance"]
    sns.heatmap(data=a,annot=True,ax=ax[0], cmap='vlag',
                cbar_kws={'ticks': [-0.05,-0.025,0.0,0.025,0.05]}, vmin=-0.05, vmax=0.05,
                fmt='.3f')
    ax[0].set(title='Average distance [m]', xlabel=None, ylabel="SNR")

    a = ap_heatmap_prep["avg_rel_tol"]-rap_heatmap_prep["avg_rel_tol"]
    sns.heatmap(data=a, annot=True, ax=ax[1], cmap='vlag',
                cbar_kws={'ticks': [-0.3,-0.15,0.0,0.15,0.3]}, vmin=-0.3, vmax=0.3,
                fmt='.3f')
    ax[1].set(title='Relative Tolerance', xlabel='Inter-source correlation', ylabel="SNR")

    plt.tight_layout()
    return fig, ax


def plot_heatmaps_fixed_ori(ap_heatmap_prep, rap_heatmap_prep):
    select_ind = range(2,5) #aiming for SNR = [-5,0,5]
    ap_heatmap_prep = ap_heatmap_prep.iloc[select_ind]
    rap_heatmap_prep = rap_heatmap_prep.iloc[select_ind]
    fig, ax = plt.subplots(2,2,sharex=True,sharey=True)

    sns.heatmap(data=ap_heatmap_prep["avg_distance"],annot=True,ax=ax[0][0])
    ax[0][0].set(title='AP avg dist[m]', xlabel=None, ylabel="SNR")

    sns.heatmap(data=rap_heatmap_prep["avg_distance"],annot=True,ax=ax[0][1])
    ax[0][1].set(title='RAP avg dist[m]', xlabel=None, ylabel=None)

    sns.heatmap(data=ap_heatmap_prep["avg_rel_tol"],annot=True,ax=ax[1][0])
    ax[1][0].set(title='AP rel_tol', xlabel="signal correlation", ylabel="SNR")

    sns.heatmap(data=rap_heatmap_prep["avg_rel_tol"],annot=True,ax=ax[1][1])
    ax[1][1].set(title='RAP rel_tol', xlabel='Inter-source correlation', ylabel="SNR")

    plt.tight_layout()
    return fig, ax
